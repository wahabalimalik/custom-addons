# -*- coding: utf-8 -*-
{
    'name': "Fleets Management System",

    'summary': """
        This module is helpfull for transportation companies to manage there system""",

    'description': """
        Track every bussiness related managerial system of transport survice Industry
    """,

    'author': "Wahab Ali Malik",
    'website': "http://bcube.com",

    'category': 'Uncategorized',
    'version': '0.1',

    'depends': ['base','account_accountant'],
    'data': [
        'views/views.xml',
    ],
} 